package com.training.ui;

import java.util.Scanner;

import com.training.bean.Book;
import com.training.service.BookService;

public class Main {
	
	static BookService bs;

	public static void main(String[] args) {
		Scanner scobj= new Scanner(System.in);
		char ch='x';
		do {
		System.out.println("1.Enter the Book Details to Insert");
		System.out.println("2.Update the Book Details Based on key");
		System.out.println("3.Delete the Book Record based on Key");
		System.out.println("4.Search Book Details Based on key");
		System.out.println("5.Display All Book Records");
		System.out.println("6.Exit");
		System.out.println("");
		System.out.println("Enter the choice");
		int choice = scobj.nextInt();
		
		switch(choice) {
		case 1 : System.out.println("Enter the bookid");
					int bid = scobj.nextInt();
					System.out.println("Enter the bookName");
					String bname= scobj.next()+scobj.nextLine();
					System.out.println("Enter the authorName");
					String bauth = scobj.nextLine();
					Book b = new Book(bid,bname,bauth);
					
					bs = new BookService();
					bs.insertBook(b);
					
					
		         System.out.println("");
		
		         break;
		case 2 :System.out.println("Book is updated");
				break;
		case 3: System.out.println("Book is deleted");
				break;
		case 4 : System.out.println("Book is found based on id");
				break;
		case 5: System.out.println("All records fetched");
				break;
		case 6: System.out.println("Exit from operation");
		         ch='X';
		         break;
		} 	
		
		}while(ch!='X');
		
		
	}
}
