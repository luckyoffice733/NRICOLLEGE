package com.training.repo;

import java.util.TreeMap;

import com.training.bean.Book;

public class BookRepo {
	TreeMap<Integer,Book> hm;
	
	public BookRepo() {
	hm = new TreeMap<>();
	}
	
	public void insertBook(Book b) {
		hm.put(11,b);
	}
	

}
