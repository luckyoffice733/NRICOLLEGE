package com.training.service;

import com.training.bean.Book;
import com.training.repo.BookRepo;

public class BookService {
   
	public BookRepo brpo;
	
	public BookService() {
		this.brpo= new BookRepo();
	}
	
	public void insertBook(Book b) {
		
		brpo.insertBook(b); //calling method from repo
	}
	
	
}
